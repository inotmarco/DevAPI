// Valida a especificação OpenAPI gerada: node validate-spec.js
const SwaggerParser = require('@apidevtools/swagger-parser');
const spec = require('./config/swagger');

SwaggerParser.validate(JSON.parse(JSON.stringify(spec)))
  .then((api) => {
    console.log(`OK: OpenAPI ${api.openapi} válida — "${api.info.title}" v${api.info.version}`);
    for (const [rota, ops] of Object.entries(api.paths)) {
      for (const [metodo, op] of Object.entries(ops)) {
        const seg = op.security && op.security.length ? 'bearer' : 'público';
        console.log(`${metodo.toUpperCase().padEnd(5)} ${rota.padEnd(36)} [${seg}] -> ${Object.keys(op.responses).join(', ')}`);
      }
    }
  })
  .catch((e) => { console.error('Especificação inválida:', e.message); process.exit(1); });
