const path = require('path');
const swaggerJsdoc = require('swagger-jsdoc');

/**
 * Definição base da OpenAPI 3.0: metadados, servidores, esquema de segurança (Bearer JWT)
 * e componentes reutilizáveis (schemas e respostas de erro padronizadas).
 * As rotas (paths) são lidas das anotações @openapi nos arquivos de /routes.
 */
const definition = {
  openapi: '3.0.3',
  info: {
    title: 'Livraria API',
    version: '1.0.0',
    description: [
      'API de **Livros e Autores** com autenticação **JWT** (stateless), senhas protegidas com **BCrypt** e controle de acesso por perfil (**RBAC**: `USER` e `ADMIN`).',
      '',
      '### Como testar rotas protegidas',
      '1. Execute **POST /api/v1/auth/login** (use *Try it out*). Contas de teste:',
      '   - ADMIN: `admin@livraria.com` / `admin123`',
      '   - USER: `leitor@gmail.com` / `leitor123`',
      '2. Copie o valor do campo `token` da resposta (o login bem-sucedido já preenche o botão **Authorize** automaticamente).',
      '3. Se preferir fazer manualmente, clique em **Authorize**, cole **apenas o token** (a interface adiciona o prefixo `Bearer `) e confirme.',
      '4. Execute as rotas marcadas com o cadeado.',
      '',
      '### Padrão de erros',
      'Todas as respostas de erro seguem o formato `{ "erro": "mensagem" }`.',
      'Falhas de validação retornam **400 Bad Request** (o código 422 não é utilizado por esta API).',
      '',
      '### Matriz de permissões',
      '| Perfil | Pode |',
      '|---|---|',
      '| Público | Listar/consultar livros e autores, registrar-se e fazer login |',
      '| USER ou ADMIN | Comentar em livros |',
      '| ADMIN | Cadastrar autores e livros |'
    ].join('\n')
  },
  servers: [
    { url: 'http://localhost:3000', description: 'Ambiente local de desenvolvimento' }
  ],
  tags: [
    { name: 'Auth', description: 'Cadastro e autenticação (rotas públicas)' },
    { name: 'Livros', description: 'Consulta pública, cadastro (ADMIN) e comentários (autenticado)' },
    { name: 'Autores', description: 'Consulta pública e cadastro (ADMIN)' }
  ],
  components: {
    securitySchemes: {
      bearerAuth: {
        type: 'http',
        scheme: 'bearer',
        bearerFormat: 'JWT',
        description: 'Token JWT obtido em `POST /api/v1/auth/login`. Informe somente o token; o prefixo `Bearer ` é adicionado automaticamente.'
      }
    },
    schemas: {
      Erro: {
        type: 'object',
        required: ['erro'],
        properties: {
          erro: { type: 'string', description: 'Mensagem descritiva do erro', example: 'Mensagem de erro.' }
        }
      },

      // ---------- Auth ----------
      RegisterRequest: {
        type: 'object',
        required: ['nome', 'email', 'senha'],
        properties: {
          nome: { type: 'string', example: 'Maria Souza' },
          email: { type: 'string', format: 'email', example: 'maria.souza@email.com', description: 'Normalizado para minúsculas. Deve ser único.' },
          senha: { type: 'string', format: 'password', minLength: 6, example: 'minhaSenha123', description: 'Mínimo de 6 caracteres. Armazenada com hash BCrypt.' }
        },
        description: 'Qualquer campo `role` enviado é ignorado: o cadastro público sempre cria perfil `USER`.'
      },
      Usuario: {
        type: 'object',
        required: ['id', 'nome', 'email', 'role'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1760000000000 },
          nome: { type: 'string', example: 'Maria Souza' },
          email: { type: 'string', format: 'email', example: 'maria.souza@email.com' },
          role: { type: 'string', enum: ['USER', 'ADMIN'], example: 'USER' }
        }
      },
      LoginRequest: {
        type: 'object',
        required: ['email', 'senha'],
        properties: {
          email: { type: 'string', format: 'email', example: 'admin@livraria.com' },
          senha: { type: 'string', format: 'password', example: 'admin123' }
        }
      },
      LoginResponse: {
        type: 'object',
        required: ['usuario', 'token'],
        properties: {
          usuario: {
            type: 'object',
            required: ['id', 'nome', 'role'],
            properties: {
              id: { type: 'integer', format: 'int64', example: 1 },
              nome: { type: 'string', example: 'Admin' },
              role: { type: 'string', enum: ['USER', 'ADMIN'], example: 'ADMIN' }
            }
          },
          token: {
            type: 'string',
            description: 'JWT assinado com HS256 (claims: sub, nome, role, iat, exp). Expira em 1h por padrão.',
            example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJub21lIjoiQWRtaW4iLCJyb2xlIjoiQURNSU4iLCJzdWIiOiIxIiwiaWF0IjoxNzYwMDAwMDAwLCJleHAiOjE3NjAwMDM2MDB9.assinatura'
          }
        }
      },

      // ---------- Autores ----------
      AutorRequest: {
        type: 'object',
        required: ['nome'],
        properties: {
          nome: { type: 'string', example: 'Clarice Lispector' },
          nacionalidade: { type: 'string', example: 'Brasileira', description: 'Opcional. Se omitido, é salvo como "Não informada".' }
        }
      },
      Autor: {
        type: 'object',
        required: ['id', 'nome', 'nacionalidade'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1 },
          nome: { type: 'string', example: 'Machado de Assis' },
          nacionalidade: { type: 'string', example: 'Brasileiro' }
        }
      },

      // ---------- Livros ----------
      LivroRequest: {
        type: 'object',
        required: ['titulo', 'autor_id'],
        properties: {
          titulo: { type: 'string', example: 'A Hora da Estrela' },
          ano: { type: 'integer', example: 1977, description: 'Opcional. Se omitido, usa o ano corrente.' },
          autor_id: { type: 'integer', format: 'int64', example: 1, description: 'ID de um autor já cadastrado.' }
        }
      },
      Comentario: {
        type: 'object',
        required: ['id', 'autor_nome', 'texto'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1 },
          autor_nome: { type: 'string', example: 'Leitor', description: 'Nome do usuário autenticado que comentou (extraído do token).' },
          texto: { type: 'string', example: 'Clássico indispensável.' }
        }
      },
      ComentarioRequest: {
        type: 'object',
        required: ['texto'],
        properties: {
          texto: { type: 'string', example: 'Leitura envolvente do início ao fim.', description: 'Não pode ser vazio ou apenas espaços.' }
        }
      },
      Livro: {
        type: 'object',
        required: ['id', 'titulo', 'ano', 'autor_id'],
        properties: {
          id: { type: 'integer', format: 'int64', example: 1760000000000 },
          titulo: { type: 'string', example: 'A Hora da Estrela' },
          ano: { type: 'integer', example: 1977 },
          autor_id: { type: 'integer', format: 'int64', example: 1 },
          comentarios: { type: 'array', items: { $ref: '#/components/schemas/Comentario' } }
        }
      },
      LivroDetalhado: {
        allOf: [
          { $ref: '#/components/schemas/Livro' },
          {
            type: 'object',
            required: ['autor_nome'],
            properties: {
              autor_nome: { type: 'string', example: 'Machado de Assis', description: '"Autor Desconhecido" se o autor não for encontrado.' }
            }
          }
        ]
      }
    },

    // Respostas de erro reutilizáveis
    responses: {
      BadRequest: {
        description: 'Requisição inválida: campo obrigatório ausente, tipo incorreto ou JSON malformado.',
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' }, example: { erro: 'Campos obrigatórios ausentes.' } } }
      },
      Unauthorized: {
        description: 'Token ausente, expirado ou inválido (ou credenciais incorretas, no login).',
        content: {
          'application/json': {
            schema: { $ref: '#/components/schemas/Erro' },
            examples: {
              tokenAusente: { summary: 'Token ausente', value: { erro: 'Token de autenticação não fornecido.' } },
              tokenExpirado: { summary: 'Token expirado', value: { erro: 'Token expirado.' } },
              tokenInvalido: { summary: 'Token corrompido/inválido', value: { erro: 'Token inválido.' } }
            }
          }
        }
      },
      Forbidden: {
        description: 'Token válido, porém o perfil do usuário não é ADMIN.',
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' }, example: { erro: 'Acesso proibido: privilégio de ADMIN exigido.' } } }
      },
      InternalError: {
        description: 'Erro interno inesperado no servidor.',
        content: { 'application/json': { schema: { $ref: '#/components/schemas/Erro' }, example: { erro: 'Ocorreu um erro interno no servidor.' } } }
      }
    }
  }
};

const spec = swaggerJsdoc({
  definition,
  apis: [path.join(__dirname, '..', 'routes', '*.js')]
});

module.exports = spec;
