const { Router } = require('express');
const controller = require('../controllers/LivroController');
const { autenticarToken, exigirRole } = require('../middlewares/authMiddleware');

const router = Router();

// Rotas Públicas

/**
 * @openapi
 * /api/v1/livros:
 *   get:
 *     tags: [Livros]
 *     summary: Lista todos os livros
 *     description: Rota **pública**. Retorna todos os livros com o nome do autor e seus comentários.
 *     security: []
 *     responses:
 *       200:
 *         description: Lista de livros.
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/LivroDetalhado'
 *             example:
 *               - id: 1
 *                 titulo: Dom Casmurro
 *                 ano: 1899
 *                 autor_id: 1
 *                 autor_nome: Machado de Assis
 *                 comentarios:
 *                   - { id: 1, autor_nome: Leitor, texto: Clássico indispensável. }
 *       500:
 *         $ref: '#/components/responses/InternalError'
 */
router.get('/', (req, res, next) => controller.index(req, res, next));

/**
 * @openapi
 * /api/v1/livros/{id}:
 *   get:
 *     tags: [Livros]
 *     summary: Busca um livro pelo ID
 *     description: Rota **pública**. Retorna os dados do livro, o nome do autor e os comentários.
 *     security: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *           format: int64
 *         description: Identificador do livro.
 *         example: 1
 *     responses:
 *       200:
 *         description: Livro encontrado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LivroDetalhado'
 *             example:
 *               id: 1
 *               titulo: Dom Casmurro
 *               ano: 1899
 *               autor_id: 1
 *               autor_nome: Machado de Assis
 *               comentarios:
 *                 - { id: 1, autor_nome: Leitor, texto: Clássico indispensável. }
 *       404:
 *         description: Livro não localizado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "Livro não localizado." }
 */
router.get('/:id', (req, res, next) => controller.show(req, res, next));

// Rota Restrita: ADMIN

/**
 * @openapi
 * /api/v1/livros:
 *   post:
 *     tags: [Livros]
 *     summary: Cadastra um novo livro (somente ADMIN)
 *     description: |
 *       Rota **restrita ao perfil ADMIN**. Exige `Authorization: Bearer <token>`.
 *       Sem token, expirado ou corrompido → 401. Token válido de perfil `USER` → 403.
 *       O `autor_id` deve referenciar um autor existente (consulte `GET /api/v1/autores`).
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LivroRequest'
 *     responses:
 *       201:
 *         description: Livro criado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Livro'
 *             example:
 *               id: 1760000000000
 *               titulo: A Hora da Estrela
 *               ano: 1977
 *               autor_id: 1
 *               comentarios: []
 *       400:
 *         description: Título ou autor_id ausentes.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "O título e o autor_id são obrigatórios." }
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       404:
 *         description: O `autor_id` informado não corresponde a nenhum autor.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "O autor informado não existe." }
 */
router.post('/', autenticarToken, exigirRole('ADMIN'), (req, res, next) => controller.store(req, res, next));

// Rota Restrita: Usuário Autenticado

/**
 * @openapi
 * /api/v1/livros/{id}/comentarios:
 *   post:
 *     tags: [Livros]
 *     summary: Adiciona um comentário a um livro (USER ou ADMIN)
 *     description: |
 *       Rota para **qualquer usuário autenticado** (`USER` ou `ADMIN`). Exige `Authorization: Bearer <token>`.
 *       O nome exibido no comentário vem do token, não do corpo da requisição.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *           format: int64
 *         description: Identificador do livro a ser comentado.
 *         example: 1
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ComentarioRequest'
 *     responses:
 *       201:
 *         description: Comentário criado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Comentario'
 *             example: { id: 1760000000000, autor_nome: Leitor, texto: Leitura envolvente do início ao fim. }
 *       400:
 *         description: Texto do comentário ausente ou vazio.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "O texto do comentário não pode estar vazio." }
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         description: Livro não localizado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "Livro não localizado." }
 */
router.post('/:id/comentarios', autenticarToken, (req, res, next) => controller.storeComment(req, res, next));

module.exports = router;
