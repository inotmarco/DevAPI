const { Router } = require('express');
const controller = require('../controllers/AuthController');

const router = Router();

/**
 * @openapi
 * /api/v1/auth/register:
 *   post:
 *     tags: [Auth]
 *     summary: Cadastra um novo usuário
 *     description: |
 *       Rota **pública**. Cria uma conta com perfil `USER` (qualquer `role` enviado no corpo é ignorado,
 *       evitando auto-promoção a ADMIN). A senha é armazenada com hash BCrypt e **nunca** é retornada.
 *       O e-mail é normalizado para minúsculas e deve ser único.
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterRequest'
 *     responses:
 *       201:
 *         description: Usuário criado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Usuario'
 *             example:
 *               id: 1760000000000
 *               nome: Maria Souza
 *               email: maria.souza@email.com
 *               role: USER
 *       400:
 *         description: Campos obrigatórios ausentes ou senha com menos de 6 caracteres.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             examples:
 *               camposAusentes:
 *                 summary: Campo obrigatório ausente
 *                 value: { erro: "Campos obrigatórios ausentes: nome, email ou senha." }
 *               senhaCurta:
 *                 summary: Senha curta
 *                 value: { erro: "A senha deve ter no mínimo 6 caracteres." }
 *       409:
 *         description: Conflito — o e-mail já está cadastrado.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "E-mail já cadastrado no sistema." }
 */
router.post('/register', (req, res, next) => controller.register(req, res, next));

/**
 * @openapi
 * /api/v1/auth/login:
 *   post:
 *     tags: [Auth]
 *     summary: Autentica o usuário e emite um token JWT
 *     description: |
 *       Rota **pública**. Valida e-mail e senha e devolve um JWT (HS256, expira em 1h por padrão) que deve ser
 *       enviado nas rotas protegidas no cabeçalho `Authorization: Bearer <token>`.
 *       E-mail inexistente e senha incorreta retornam a mesma mensagem (evita enumeração de usuários).
 *     security: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *           examples:
 *             admin:
 *               summary: Administrador
 *               value: { email: admin@livraria.com, senha: admin123 }
 *             leitor:
 *               summary: Usuário comum
 *               value: { email: leitor@gmail.com, senha: leitor123 }
 *     responses:
 *       200:
 *         description: Login realizado com sucesso.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/LoginResponse'
 *       400:
 *         description: E-mail ou senha não informados.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "E-mail e senha são obrigatórios." }
 *       401:
 *         description: Credenciais inválidas.
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Erro'
 *             example: { erro: "Credenciais inválidas." }
 */
router.post('/login', (req, res, next) => controller.login(req, res, next));

module.exports = router;
