const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');

const swaggerSpec = require('./config/swagger');
const authRoutes = require('./routes/authRoutes');
const livroRoutes = require('./routes/livroRoutes');
const autorRoutes = require('./routes/autorRoutes');
const errorHandler = require('./middlewares/errorMiddleware');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// No Express 5, req.body fica undefined quando não há corpo JSON.
// Garante um objeto vazio para que a validação responda 400 (e não 500).
app.use((req, res, next) => {
  if (req.body === undefined) req.body = {};
  next();
});

// Documentação OpenAPI 3.0
// - Especificação bruta (JSON): GET /docs/api.json
// - Interface interativa (Swagger UI): GET /docs
app.get('/docs/api.json', (req, res) => res.json(swaggerSpec));
app.use(
  '/docs',
  swaggerUi.serve,
  swaggerUi.setup(swaggerSpec, {
    customSiteTitle: 'Livraria API — Documentação',
    swaggerOptions: {
      persistAuthorization: true,
      // Após um login bem-sucedido, preenche o botão "Authorize" automaticamente.
      responseInterceptor: function (res) {
        try {
          if (res.url && res.url.endsWith('/api/v1/auth/login') && res.status === 200) {
            var corpo = typeof res.body === 'string' ? JSON.parse(res.body) : res.body;
            if (corpo && corpo.token && window.ui) {
              window.ui.preauthorizeApiKey('bearerAuth', corpo.token);
            }
          }
        } catch (e) { /* o Authorize manual continua disponível */ }
        return res;
      }
    }
  })
);

// Agrupamento Semântico de Rotas (RESTful /api/v1)
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/livros', livroRoutes);
app.use('/api/v1/autores', autorRoutes);

// Middleware Global de Tratamento de Erros
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Livraria API rodando em http://localhost:${PORT}`);
  console.log(`Documentação interativa em http://localhost:${PORT}/docs`);
});
